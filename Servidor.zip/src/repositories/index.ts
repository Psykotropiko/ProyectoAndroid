export * from './pelicula.repository';
