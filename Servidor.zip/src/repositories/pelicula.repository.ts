import {DefaultCrudRepository} from '@loopback/repository';
import {Pelicula, PeliculaRelations} from '../models';
import {AccountDsDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class PeliculaRepository extends DefaultCrudRepository<
  Pelicula,
  typeof Pelicula.prototype.id,
  PeliculaRelations
> {
  constructor(
    @inject('datasources.accountDS') dataSource: AccountDsDataSource,
  ) {
    super(Pelicula, dataSource);
  }
}
