import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {Pelicula} from '../models';
import {PeliculaRepository} from '../repositories';

export class CineController {
  constructor(
    @repository(PeliculaRepository)
    public peliculaRepository : PeliculaRepository,
  ) {}

  @post('/peliculas', {
    responses: {
      '200': {
        description: 'Pelicula model instance',
        content: {'application/json': {schema: getModelSchemaRef(Pelicula)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pelicula, {
            title: 'NewPelicula',
            exclude: ['id'],
          }),
        },
      },
    })
    pelicula: Omit<Pelicula, 'id'>,
  ): Promise<Pelicula> {
    return this.peliculaRepository.create(pelicula);
  }

  @get('/peliculas/count', {
    responses: {
      '200': {
        description: 'Pelicula model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Pelicula)) where?: Where<Pelicula>,
  ): Promise<Count> {
    return this.peliculaRepository.count(where);
  }

  @get('/peliculas', {
    responses: {
      '200': {
        description: 'Array of Pelicula model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Pelicula, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Pelicula)) filter?: Filter<Pelicula>,
  ): Promise<Pelicula[]> {
    return this.peliculaRepository.find(filter);
  }

  @patch('/peliculas', {
    responses: {
      '200': {
        description: 'Pelicula PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pelicula, {partial: true}),
        },
      },
    })
    pelicula: Pelicula,
    @param.query.object('where', getWhereSchemaFor(Pelicula)) where?: Where<Pelicula>,
  ): Promise<Count> {
    return this.peliculaRepository.updateAll(pelicula, where);
  }

  @get('/peliculas/{id}', {
    responses: {
      '200': {
        description: 'Pelicula model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Pelicula, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Pelicula)) filter?: Filter<Pelicula>
  ): Promise<Pelicula> {
    return this.peliculaRepository.findById(id, filter);
  }

  @patch('/peliculas/{id}', {
    responses: {
      '204': {
        description: 'Pelicula PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pelicula, {partial: true}),
        },
      },
    })
    pelicula: Pelicula,
  ): Promise<void> {
    await this.peliculaRepository.updateById(id, pelicula);
  }

  @put('/peliculas/{id}', {
    responses: {
      '204': {
        description: 'Pelicula PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() pelicula: Pelicula,
  ): Promise<void> {
    await this.peliculaRepository.replaceById(id, pelicula);
  }

  @del('/peliculas/{id}', {
    responses: {
      '204': {
        description: 'Pelicula DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.peliculaRepository.deleteById(id);
  }
}
