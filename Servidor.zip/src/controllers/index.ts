export * from './ping.controller';
export * from './cine.controller';
