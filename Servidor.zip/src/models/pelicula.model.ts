import {Entity, model, property} from '@loopback/repository';

@model()
export class Pelicula extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
  })
  id: string;

  @property({
    type: 'string',
  })
  titulo?: string;

  @property({
    type: 'string',
  })
  director?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  reparto?: string[];

  @property({
    type: 'string',
  })
  sinopsis?: string;

  @property({
    type: 'string',
  })
  genero?: string;

  @property({
    type: 'string',
  })
  imagen_url?: string;

  @property({
    type: 'number',
  })
  valoracion?: number;

  @property({
    type: 'number',
  })
  lanzamiento?: number;

  @property({
    type: 'string',
  })
  duracion?: string;

  @property({
    type: 'string',
  })
  publico?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  sesiones?: string[];


  constructor(data?: Partial<Pelicula>) {
    super(data);
  }
}

export interface PeliculaRelations {
  // describe navigational properties here
}

export type PeliculaWithRelations = Pelicula & PeliculaRelations;
