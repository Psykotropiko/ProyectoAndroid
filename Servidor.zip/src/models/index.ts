export * from './pelicula.model';
