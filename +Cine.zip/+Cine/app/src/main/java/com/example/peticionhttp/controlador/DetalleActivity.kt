package com.example.peticionhttp.controlador

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.peticionhttp.R
import com.squareup.picasso.Picasso

class DetalleActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle)
        val textTitulo = findViewById<TextView>(R.id.titulo)
        val textDirector = findViewById<TextView>(R.id.director)
        val textReparto = findViewById<TextView>(R.id.reparto)
        val textSinopsis = findViewById<TextView>(R.id.sinopsis)
        val imageView = findViewById<ImageView>(R.id.imagen)
        val textValoracion = findViewById<TextView>(R.id.valoracion)
        val textLanzamiento = findViewById<TextView>(R.id.lanzamiento)
        val textPublico = findViewById<TextView>(R.id.publico)
        val imagen = intent.getStringExtra("imagen_url")


        Picasso.with(this@DetalleActivity).load(imagen).into(imageView)


        val titulo = intent.getStringExtra("titulo")
        val director = intent.getStringExtra("director")
        val reparto = intent.getSerializableExtra("reparto")
        val sinopsis = intent.getStringExtra("sinopsis")

        val valoracion = intent.getStringExtra("valoracion")
        val lanzamiento = intent.getStringExtra("lanzamiento")
        val duracion = intent.getStringExtra("duracion")
        val publico = intent.getStringExtra("publico")
        val sesiones = intent.getSerializableExtra("sesiones")


        textTitulo.text = titulo
        textDirector.text = "Director: " + director
        textReparto.text = "Reparto: "+reparto.toString()
        textSinopsis.text = "Duracion: "+duracion+"\n" +"\n"+sinopsis+"\n" +"\n"+"Sesiones: "+sesiones.toString()

        textValoracion.text = "Valoración del público: "+valoracion
        textLanzamiento.text = "Año de lanzamiento: "+lanzamiento
        textPublico.text = "Público recomendado: "+publico






    }


}