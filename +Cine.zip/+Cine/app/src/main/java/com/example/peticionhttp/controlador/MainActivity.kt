package com.example.peticionhttp.controlador

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.peticionhttp.modelo.Pelicula
import com.example.peticionhttp.modelo.PeticionHttp
import com.example.peticionhttp.R
import com.squareup.picasso.Picasso

class MainActivity : AppCompatActivity() {


    private lateinit var adaptador: Adaptador
    private lateinit var listPeliculas: ArrayList<Pelicula>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val listView = findViewById<ListView>(R.id.listView)
        val boton = findViewById<Button>(R.id.button)
        listPeliculas = ArrayList<Pelicula>()
        adaptador = Adaptador(
            this,
            listPeliculas
        )
        listView.adapter = adaptador
        listView.setOnItemClickListener { parent, view, position, id ->
            val intent = Intent(this@MainActivity, DetalleActivity::class.java).apply {
                putExtra("titulo", listPeliculas[position].titulo)
                putExtra("director", listPeliculas[position].director)
                putExtra("reparto", listPeliculas[position].reparto)
                putExtra("sinopsis", listPeliculas[position].sinopsis)
                putExtra("genero", listPeliculas[position].genero)
                putExtra("imagen_url", listPeliculas[position].imagen_url)
                putExtra("valoracion", listPeliculas[position].valoracion.toString())
                putExtra("lanzamiento",listPeliculas[position].lanzamiento.toString())
                putExtra("duracion", listPeliculas[position].duracion)
                putExtra("publico", listPeliculas[position].publico)
                putExtra("sesiones", listPeliculas[position].sesiones)
            }
            startActivity(intent)
        }
        actualizar(this)

        boton.setOnClickListener {
            actualizar(this)
        }



    }

    fun actualizar(context: Context){
        PeticionHttp(context).peticion_json({ response ->
            this.listPeliculas.clear()
            this.listPeliculas.addAll(response)
            adaptador.notifyDataSetChanged()
        })
    }

    private class Adaptador(context: Context, peliculas: List<Pelicula>) : BaseAdapter(){
        private  val mContext : Context
        private val peliculas : List<Pelicula>

        init {
            mContext = context
            this.peliculas = peliculas
        }
        override fun getCount(): Int {
            return peliculas.size
        }

        override fun getItem(position: Int): Any {
            return ""
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val layoutInflater = LayoutInflater.from(mContext)
            val fila = layoutInflater.inflate(R.layout.fila, parent, false)
            val titulo = fila.findViewById<TextView>(R.id.titulo)
            val duracion = fila.findViewById<TextView>(R.id.duracion)
            val imagen = fila.findViewById<ImageView>(R.id.imagen)
            titulo.text = peliculas[position].titulo
            duracion.text = peliculas[position].duracion
            Picasso.with(mContext).load(peliculas[position].imagen_url).into(imagen)
            return fila
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }
    }




}
