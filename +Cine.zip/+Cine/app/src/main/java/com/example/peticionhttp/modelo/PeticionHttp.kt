package com.example.peticionhttp.modelo

import android.content.Context
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson

const val url = "http://192.168.1.114:3000/peliculas"

class PeticionHttp (contexto: Context){

    val contexto : Context
    var cola : MySingleton
    init {
        this.contexto = contexto
        this.cola = MySingleton.getInstance(this.contexto)
    }
    fun peticion(callback: (String)-> Unit ) {
        val queue = Volley.newRequestQueue(this.contexto)
        // Request a string response from the provided URL.
        val stringRequest = StringRequest(Request.Method.GET,
            url,
            Response.Listener<String> { response ->
                callback(response.toString())

            },
            Response.ErrorListener { callback("That didn't work!") })

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
    fun peticion_json(callback: (List<Pelicula>) -> Unit){
        val jsonArrayRequest = JsonArrayRequest(Request.Method.GET,
            url, null,
            Response.Listener { response ->
                //callback(response.toString())
                val peliculas = parse_json(response.toString())
                callback(peliculas)
            },
            Response.ErrorListener { error ->
                Toast.makeText(this.contexto, error.toString(), Toast.LENGTH_SHORT)
            }
        )
        // Access the RequestQueue through your singleton class.
        this.cola.addToRequestQueue(jsonArrayRequest)
    }

    fun parse_json(archivo : String) : List<Pelicula> {
        val gson = Gson()
        val peliculas : List<Pelicula> = gson.fromJson(archivo,Array<Pelicula>::class.java).toList()
        return peliculas

    }
}