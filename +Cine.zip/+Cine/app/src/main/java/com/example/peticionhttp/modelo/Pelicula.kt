package com.example.peticionhttp.modelo

data class Pelicula (val id : String,
               val titulo : String,
               val director: String,
               val reparto: ArrayList<String>,
               val sinopsis : String,
               val genero: String,
               val imagen_url : String,
               val valoracion : Double,
               val lanzamiento: Int,
               val duracion: String,
               val publico: String,
               val sesiones: ArrayList<String>
               )