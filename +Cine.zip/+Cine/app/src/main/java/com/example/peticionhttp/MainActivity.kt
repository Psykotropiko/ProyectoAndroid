package com.example.peticionhttp

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.squareup.picasso.Picasso

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val listView = findViewById<ListView>(R.id.listView)

        var cadena : String
        PeticionHttp(this).peticion_json({ response ->
            listView.adapter = Adaptador(this, response)
        })


    }


    private class Adaptador(context: Context, peliculas: List<Pelicula>) : BaseAdapter(){
        private  val mContext : Context
        private val peliculas : List<Pelicula>

        init {
            mContext = context
            this.peliculas = peliculas
        }
        override fun getCount(): Int {
            return peliculas.size
        }

        override fun getItem(position: Int): Any {
            return "que pasa"
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val layoutInflater = LayoutInflater.from(mContext)
            val fila = layoutInflater.inflate( R.layout.fila, parent, false)
            val titulo = fila.findViewById<TextView>(R.id.titulo)
            val duracion = fila.findViewById<TextView>(R.id.duracion)
            val imagen = fila.findViewById<ImageView>(R.id.imagen)
            titulo.text = peliculas[position].titulo
            duracion.text = peliculas[position].duracion
            Picasso.with(mContext).load(peliculas[position].imagen_url).into(imagen)
            return fila
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }
    }




}
